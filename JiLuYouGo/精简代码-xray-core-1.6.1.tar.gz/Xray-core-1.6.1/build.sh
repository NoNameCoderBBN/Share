#!/bin/bash

go build -o xray -trimpath -ldflags "-s -w -buildid=" ./main

